# Ore CLI JITO

Go into the `ore-cli/src` directory and open the send_and_confirm.rs file.

Make sure you have this installed 
https://grpc.io/docs/protoc-installation/#install-pre-compiled-binaries-any-os`
 
If you have an issue ask ChatGPT or claude about it.

Find this line:
```rust
let keypair = Arc::new(read_keypair_file(&"/home/ubuntu/jito_keypair.json".to_string()).expect("reads keypair at path"));
```

Replace this with your jito keypair path.
/home/ubuntu/jito_keypair.json

```sh
cargo run --release mine --threads "num_threads" --keypair "keypair_path" --rpc "rpc_url"
```
