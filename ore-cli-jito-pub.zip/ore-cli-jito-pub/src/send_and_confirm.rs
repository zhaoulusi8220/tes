use std::{sync::Arc, str::FromStr};
use colored::*;
use solana_client::{
    client_error::{ClientError, ClientErrorKind, Result as ClientResult},
    nonblocking::rpc_client::RpcClient,
};
use solana_program::{
    instruction::Instruction,
    system_instruction::transfer,
    native_token::{lamports_to_sol, sol_to_lamports},
};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction,
    signature::{Signature, Keypair, Signer, read_keypair_file},
    transaction::{Transaction, VersionedTransaction},
    pubkey::Pubkey,
};
use jito_searcher_client::{send_bundle_no_wait, get_searcher_client};
use jito_protos::searcher::NextScheduledLeaderRequest;
use crate::Miner;
use futures::future::join_all;

const MIN_SOL_BALANCE: f64 = 0.005;

pub enum ComputeBudget {
    Dynamic,
    Fixed(u32),
}

impl Miner {
    pub async fn send_and_confirm(
        &self,
        ixs: &[Instruction],
        compute_budget: ComputeBudget,
        _skip_confirm: bool,
    ) -> ClientResult<Signature> {
        let signer = self.signer();
        let client = self.rpc_client.clone();
        let keypair = Arc::new(read_keypair_file(&"/home/ubuntu/jito_keypair.json".to_string()).expect("reads keypair at path"));
        
        let urls = vec![
            "https://amsterdam.mainnet.block-engine.jito.wtf",
            "https://frankfurt.mainnet.block-engine.jito.wtf",
            "https://tokyo.mainnet.block-engine.jito.wtf",
            "https://ny.mainnet.block-engine.jito.wtf"
        ];

        // Find the client with the closest upcoming slot leader
        let (closest_url, _) = {
            let futures = urls.iter().map(|url| {
                let keypair_clone = keypair.clone();
                async move {
                    let mut fclient = get_searcher_client(url, &keypair_clone).await.expect("Failed to create client");
                    let next_leader = fclient.get_next_scheduled_leader(NextScheduledLeaderRequest {
                        regions: vec![],
                    }).await.expect("Failed to get next leader").into_inner();
                    (url, next_leader)
                }
            });
            let results = join_all(futures).await;
            results.into_iter()
                .min_by_key(|(_, leader)| leader.next_leader_slot - leader.current_slot)
                .expect("Failed to find the closest upcoming slot leader")
        };

        let mut jito_client = get_searcher_client(closest_url, &keypair)
            .await
            .expect("connects to searcher client");

        // Check balance
        if let Ok(balance) = client.get_balance(&signer.pubkey()).await {
            if balance <= sol_to_lamports(MIN_SOL_BALANCE) {
                panic!(
                    "{} Insufficient balance: {} SOL\nPlease top up with at least {} SOL",
                    "ERROR".bold().red(),
                    lamports_to_sol(balance),
                    MIN_SOL_BALANCE
                );
            }
        }

        // Prepare instructions
        let mut final_ixs = vec![];
        match compute_budget {
            ComputeBudget::Dynamic => {
                final_ixs.push(ComputeBudgetInstruction::set_compute_unit_limit(1_400_000))
            }
            ComputeBudget::Fixed(cus) => {
                final_ixs.push(ComputeBudgetInstruction::set_compute_unit_limit(cus))
            }
        }
        let recipient_pubkey_str = "DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL";
        let recipient_pubkey = Pubkey::from_str(recipient_pubkey_str).expect("Failed to parse recipient pubkey");

        final_ixs.push(transfer(&signer.pubkey(), &recipient_pubkey, 10_001));
        final_ixs.push(ComputeBudgetInstruction::set_compute_unit_price(self.priority_fee));
        final_ixs.extend_from_slice(ixs);

        // Build transaction
        let (hash, _) = client
            .get_latest_blockhash_with_commitment(self.rpc_client.commitment())
            .await
            .unwrap();
        let mut tx = Transaction::new_with_payer(&final_ixs, Some(&signer.pubkey()));
        tx.sign(&[&signer], hash);

        // Convert to VersionedTransaction for Jito
        let versioned_tx = VersionedTransaction::from(tx);

        // Send the transaction three times in quick succession
        for _ in 0..3 {
            let _ = send_bundle_no_wait(&[versioned_tx.clone()], &mut jito_client).await;
        }

        // Return the signature without waiting for confirmation
        Ok(versioned_tx.signatures[0])
    }
}